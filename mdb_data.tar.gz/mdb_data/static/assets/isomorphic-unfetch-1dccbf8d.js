import{g as e}from"./@babel-24c3f70d.js";import{r}from"./unfetch-09d65dde.js";var t=self.fetch||(self.fetch=r.default||r);const s=e(t);export{s as f};
