var n=function(){},a=n;export{a as w};
