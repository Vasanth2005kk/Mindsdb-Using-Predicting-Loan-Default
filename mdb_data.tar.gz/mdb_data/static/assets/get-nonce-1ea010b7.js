var e,n=function(){if(e)return e;if(typeof __webpack_nonce__<"u")return __webpack_nonce__};export{n as g};
