function i(t,n,e){return e=typeof e!="string"?" ":e,String(t).replace(/^/gm,e.repeat(n))}var r=i;export{r as l};
