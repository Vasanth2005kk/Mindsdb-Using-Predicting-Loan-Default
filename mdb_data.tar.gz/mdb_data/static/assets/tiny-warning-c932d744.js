var i=!0;function t(n,o){if(!i){if(n)return;var r="Warning: "+o;typeof console<"u"&&console.warn(r);try{throw Error(r)}catch{}}}export{t as w};
