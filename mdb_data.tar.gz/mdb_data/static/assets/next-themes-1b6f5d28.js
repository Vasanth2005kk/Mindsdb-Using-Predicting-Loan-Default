import{r as t}from"./react-6e6d1465.js";const r=t.createContext(void 0),o={setTheme:e=>{},themes:[]},n=()=>{var e;return(e=t.useContext(r))!==null&&e!==void 0?e:o};export{n as y};
