import{g as r}from"./@babel-24c3f70d.js";var t={trueFunc:function(){return!0},falseFunc:function(){return!1}};const u=r(t);export{t as a,u as b};
